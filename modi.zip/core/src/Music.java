import com.idk.core.ObjectModifier;
import com.idk.core.EngineInterface;
import android.content.res.AssetFileDescriptor;
import com.idk.core.AssetFile;
import android.media.MediaPlayer;
public class Music extends ObjectModifier{

private MediaPlayer player;
public void onStart(){
}
public void onDelete(){

}

}