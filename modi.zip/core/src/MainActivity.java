package idkengine.my.game;


import android.app.Activity;
import android.os.Bundle;
import com.idk.core.*;
import com.idk.parser.*;
import java.io.*;
import android.widget.*;
import static android.opengl.GLES30.*;
import android.view.Window;
import android.content.pm.ActivityInfo;
public class MainActivity extends Activity {
public BaseEngine engine;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
requestWindowFeature(Window.FEATURE_NO_TITLE);
//setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
try{
//System.setOut(new PrintStream(getExternalMediaDirs()[0]+"/out.txt"));
//System.setErr(new PrintStream(getExternalMediaDirs()[0]+"/err.txt"));
engine = new BaseEngine(this);
setContentView(engine.getView());
new Thread(){ public void run(){
try{
String data = readFile(getAssets().open("level1.scn"));
Scene scene = ObjectParser.fromString(data,getClassLoader());
engine.addScene(scene);

} catch (Exception e){}
}}.start();
}catch(Exception e){
e.printStackTrace();
}
    }
@Override
public void onResume(){
super.onResume();
//engine.resume();
}

@Override
public void onPause(){
super.onPause();
//engine.pause();
}


public String readFile(InputStream ins){
    StringBuilder stringBuilder = new StringBuilder();
    try {
   BufferedReader reader = new BufferedReader(new InputStreamReader(ins));
        String line = "";
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line).append("\n");
        }
    }catch(Exception e){
		e.printStackTrace();
    }
    return stringBuilder.toString();
  }
}