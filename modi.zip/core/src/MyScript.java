package com.test;
import com.idk.core.ObjectModifier;
import com.idk.core.TouchManager;
import com.idk.simple.Rigidbody;
import com.idk.math.Vector2;
import com.idk.core.TouchListener;
import com.idk.core.TouchData;
import com.idk.core.AssetFile;
import android.media.MediaPlayer;
import android.media.SoundPool;
import java.util.Random;
import com.idk.core.GameObject;
import com.idk.simple.SpriteRenderer;
public class MyScript extends ObjectModifier{

private Rigidbody body;
private TouchManager touch;
public float force;
public float speed;
private float x;
private float y;
private boolean loss;
private boolean start;
private MediaPlayer player;
private SoundPool pool;
private int lossID;
private Vector2 origin;
private int swing;
private int win;
private int hit;
private int lode;
private GameObject jm;
private GameObject wn;
private long delay;
private GameObject text;

private void search(){
for(GameObject go : targetObject.targetScene.getObjectArray()){
if(go.name.equals("jump")){
jm = go; 
}else if(go.name.equals("win")){
wn = go;
}else if(go.name.equals("text")){
text = go;
}
}
}

@Override
public void onStart(){
body = targetObject.getModifierAssignable(Rigidbody.class).get(0);
touch = targetObject.targetScene.targetInstance.getTouchManager();
x = targetObject.transform.position.x;

y = targetObject.transform.position.y;

pool = new SoundPool(16,3,0);
lossID = pool.load(targetObject.targetScene.targetInstance.getAssetFile("loss.mp3").getFileDescriptor(),0);

swing = pool.load(targetObject.targetScene.targetInstance.getAssetFile("swing.mp3").getFileDescriptor(),0);

win = pool.load(targetObject.targetScene.targetInstance.getAssetFile("win.mp3").getFileDescriptor(),0);

hit = pool.load(targetObject.targetScene.targetInstance.getAssetFile("hit.mp3").getFileDescriptor(),0);

lode = pool.load(targetObject.targetScene.targetInstance.getAssetFile("lode.mp3").getFileDescriptor(),0);

player = new MediaPlayer();

body.getAvailableInterface().removeRigidbody(body);

origin = new Vector2(x,y);

search();


}


private void setPlayer(){
try{
player.reset();
AssetFile file = targetObject.targetScene.targetInstance.getAssetFile("music.mp3");
player.setDataSource(file.getFileDescriptor());
player.prepare();
player.setVolume(0.5f,0.5f);
player.start();
}catch(Exception e){
}
}
private boolean press;
@Override
public void onPostUpdate(){
text.transform.position.set(
targetObject.transform.position.x,
targetObject.transform.position.y
);
if(delay > System.currentTimeMillis()){
return;
}
if(touch.getTouchCount() == 1){
if(!press){
down();
}
press = true;
}else{
press = false;
}
if(start && !loss){
x += targetObject.targetScene.targetInstance.getDeltaTime() * speed;
targetObject.transform.position.x = x;
}
if(body.getCollisionList().size() > 0){
delay = System.currentTimeMillis() + 1000;
loss = true;
body.getAvailableInterface().removeRigidbody(body);
player.stop();
pool.play(hit,1f,1f,0,0,1f);
jm.transform.position.set(targetObject.transform.position.x,
targetObject.transform.position.y);
jm.active = true;
int i = new Random().nextInt(10);
if(i > 5){
//pool.play(lossID,1f,1f,0,0,1f);
}else{
//pool.play(lode,1f,1f,0,0,1f);
}
}
if(start && x > 1250){
delay = System.currentTimeMillis() + 1000;
player.stop();
pool.play(win,1f,1f,0,0,1f);
start = false;
loss = true;
body.getAvailableInterface().removeRigidbody(body);
wn.active = true;
wn.transform.position.set(targetObject.transform.position.x,
targetObject.transform.position.y);
}
}
private void down(){
if(loss){
set();
return;
}
if(!start){
start();
x = origin.x;
}else if(!loss){
body.getAvailableInterface().clearForce(body);
body.applyForce(new Vector2(0,force));
pool.play(swing,1f,1f,0,0,1f);
}
}
private void start(){
start = true;
body.getAvailableInterface().addRigidbody(body);
targetObject.transform.position.set(origin.x,origin.y);
setPlayer();
}
public void set(){
targetObject.transform.position.set(origin.x,origin.y);
loss = false;
start = false;
x = 0;
jm.active = false;
wn.active = false;
}


}